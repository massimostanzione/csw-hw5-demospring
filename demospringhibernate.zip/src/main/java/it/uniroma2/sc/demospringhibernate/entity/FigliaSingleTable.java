package it.uniroma2.sc.demospringhibernate.entity;

import javax.persistence.*;

@Entity
public class FigliaSingleTable extends MadreSingleTable {

    private int altroNumero;
}
