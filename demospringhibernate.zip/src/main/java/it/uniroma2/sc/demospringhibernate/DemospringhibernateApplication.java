package it.uniroma2.sc.demospringhibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemospringhibernateApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemospringhibernateApplication.class, args);
    }

}
