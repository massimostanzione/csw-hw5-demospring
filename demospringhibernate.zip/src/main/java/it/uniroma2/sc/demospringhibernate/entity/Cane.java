package it.uniroma2.sc.demospringhibernate.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
@Data
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Cane {
    @Id
    @GeneratedValue
    private Long id;

    private String nome;

    @ManyToOne
    private Persona padrone;

    protected Cane() {

    }

    public Cane(String nome, Persona padrone) {
        this.nome = nome;
        this.padrone = padrone;
    }

    @Override
    public String toString() {
        return "Cane{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", padrone=" + padrone +
                '}';
    }
}
