package it.uniroma2.sc.demospringhibernate.entity;

import javax.persistence.*;

@Entity
public abstract class FigliaAstrattaTablePerClass extends MadreTablePerClass{

    private int altroNumero;
}
